﻿namespace PixelPhoto.Helpers.Model.Editor
{
    public enum ColorType
    {
        ColorNormal,
        ColorGradient,
        ColorNormalAndGradient
    }
}