﻿namespace PixelPhoto.Helpers.Model.Editor
{
    public enum ToolType
    {
        Brush,
        Text,
        Eraser,
        Filter,
        FilterColor,
        Emojis,
        Sticker,
        Image,
        Color,
        CropImage,
    }
}