﻿namespace PixelPhoto.Helpers.Model.Editor
{
    public interface IOnItemSelected
    {
        void OnToolSelected(ToolType toolType);
    }
}